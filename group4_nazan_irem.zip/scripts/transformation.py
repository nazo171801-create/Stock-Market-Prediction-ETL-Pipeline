"""
====================================================================================================
PROJE ADI: Uçtan Uca Hisse Senedi Analitik ve Tahmin Projesi (2025-2026 Term Homework)
MODÜL: transformation.py (Veri Dönüştürme Katmanı)

BU KODDA NE YAPILIYOR?
Bu modül, Pandas formatında çekilen ham verileri PySpark DataFrame yapısına dönüştürür ve 
üzerinde ileri seviye veri manipülasyonları gerçekleştirir. Veri tiplerinin (Double, Date) 
düzenlenmesi, mükerrer kayıtların temizlenmesi ve zaman serisi analizleri için hayati önem 
taşıyan "Window" fonksiyonları ile özellik türetme işlemlerini yapar.

====================================================================================================
"""

from pyspark.sql import SparkSession, Window
from pyspark.sql.functions import col, to_date, when, lead, lag, lit
from pyspark.sql.types import DoubleType

def transform_price_data(spark: SparkSession, df_pd):
    # Pandas DataFrame'den PySpark DataFrame'e geçiş  
    df = spark.createDataFrame(df_pd)

    # Veri tiplerinin modelleme için standardize edilmesi
    df = df.withColumn("Date", to_date(col("Date"))) \
           .withColumn("Close", col("Close").cast(DoubleType())) \
           .withColumn("Open", col("Open").cast(DoubleType())) \
           .withColumn("Volume", col("Volume").cast(DoubleType()))

    # Window Fonksiyonu: Her bir hisse (Ticker) bazında tarihsel sıralama yapar.
    w = Window.partitionBy("Ticker").orderBy("Date")

    # Gelecek günün açılış fiyatı (Lead) ve Günlük Getiri (Lag) hesaplamaları
    df = df.withColumn("next_day_open", lead("Open", 1).over(w)) \
           .withColumn("daily_return",
                       (col("Close") - lag("Close", 1).over(w)) /
                       lag("Close", 1).over(w)) \
           .withColumn("transaction_fee", lit(0.001)) # 1/1000 İşlem maliyeti tanımı 

    # 🔒 KESİN PERİYOT AYRIMI
    df = df.withColumn(
        "period_type",
        when(col("Date") < "2020-01-01", "TRAIN")        # Başlangıç - 2020
        .when(col("Date") < "2023-01-01", "TEST")         # 2020 - 2023
        .when(col("Date") < "2024-01-01", "VALIDATION")   # 2023 - 2024
        .otherwise("PREDICTION")                           # 2024 - 2025
    )

    return df.dropDuplicates(["Date", "Ticker"])

def transform_financials(spark: SparkSession, df_pd):
    """Finansal tabloların temel tarih formatlama işlemlerini yapar."""
    return spark.createDataFrame(df_pd) \
        .withColumn("Date", to_date(col("Date")))