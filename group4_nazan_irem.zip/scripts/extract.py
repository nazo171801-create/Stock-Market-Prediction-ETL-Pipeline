"""
====================================================================================================
PROJE ADI: Uçtan Uca Hisse Senedi Analitik ve Tahmin Projesi (2025-2026 Term Homework)
MODÜL: extract.py (Veri Çıkarma Katmanı)

BU KODDA NE YAPILIYOR?
Bu modül, yfinance kütüphanesini kullanarak Yahoo Finance API üzerinden finansal verilerin 
programatik olarak çekilmesini sağlar. Projede kullanılan 10 adet teknoloji hissesi, 
4 temel borsa endeksi ve 6 farklı makroekonomik göstergeye ait tarihsel fiyat verileri 
ile şirketlerin finansal tablolarını (Gelir Tablosu, Bilanço, Nakit Akışı) toplar.

====================================================================================================
"""

import yfinance as yf
import pandas as pd
import logging
from typing import List, Dict


# Ticker Tanımları 
STOCKS = ["AAPL", "NVDA", "MSFT", "AVGO", "META", "AMZN", "TSLA", "GOOGL", "AMD", "INTC"]
INDICES = ["^GSPC", "NQ=F", "RTY=F", "^DJI"]

# Makro veriler 
MACROS = {
    "UKOIL": "BZ=F",
    "US2Y": "ZT=F",
    "US10Y": "^TNX",
    "DXY": "DX-Y.NYB",
    "VIX": "^VIX",
    "GOLD": "GC=F"
}

# Zaman aralığı 10 yılı aşkın bir süreyi kapsayacak şekilde ayarlanmıştır.
START_DATE = "2013-01-01"
END_DATE = "2025-12-31"

def extract_price_data(ticker_list: List[str]) -> pd.DataFrame:
    """
    Belirtilen ticker listesi için OHLCV (Açılış, Yüksek, Düşük, Kapanış, Hacim) 
    verilerini indirir ve birleştirir.
    """
    all_data = []
    for ticker in ticker_list:
        try:
            # auto_adjust=False: Temel verilerin (Open, Close vb.) ham halini korur.
            df = yf.download(ticker, start=START_DATE, end=END_DATE, auto_adjust=False, progress=False)
            df = df.reset_index()
            
            # MultiIndex temizliği: Sütun başlıklarını düz bir liste haline getirir.
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = [col[0] for col in df.columns]
            
            df["Ticker"] = ticker
            all_data.append(df)
            print(f"Indirildi: {ticker}")
        except Exception as e:
            print(f"Hata {ticker}: {e}")
    
    combined = pd.concat(all_data, ignore_index=True)
    # SQL sütun ismi standartlarına uygunluk için boşluklar alt tireye çevrilir.
    combined.columns = [str(c).replace(" ", "_") for c in combined.columns]
    return combined

def extract_financials(ticker_list: List[str]) -> pd.DataFrame:
    """
    Şirketlerin finansal metriklerini (Income Statement, Balance Sheet, Cash Flow) 
    çekerek analiz edilebilir dikey formata dönüştürür.
    """
    all_rows = []

    for ticker in ticker_list:
        try:
            t = yf.Ticker(ticker)

            for stmt_name, stmt in {
                "income": t.financials,
                "balance": t.balance_sheet,
                "cashflow": t.cashflow
            }.items():
                if stmt is not None and not stmt.empty:
                    # Transpoz (.T) alarak tarihleri satıra, metrikleri sütuna taşırız.
                    df = stmt.T.reset_index().rename(columns={"index": "Date"})
                    # Melt işlemi: Geniş tabloyu uzun tabloya çevirerek veritabanı dostu yapar.
                    df_melt = df.melt(
                        id_vars=["Date"],
                        var_name="Metric",
                        value_name="Value"
                    )
                    df_melt["Ticker"] = ticker
                    df_melt["Statement"] = stmt_name
                    all_rows.append(df_melt)

        except Exception as e:
            logging.error(f"Financial fetch error {ticker}: {e}")
        
    return pd.concat(all_rows, ignore_index=True)