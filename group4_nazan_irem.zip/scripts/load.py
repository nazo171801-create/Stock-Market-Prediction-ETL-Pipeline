"""
====================================================================================================
PROJE ADI: Uçtan Uca Hisse Senedi Analitik ve Tahmin Projesi (2025-2026 Term Homework)
MODÜL: load.py (Veri Yükleme Katmanı)

BU KODDA NE YAPILIYOR?
Bu modül, PySpark DataFrame üzerinde temizlenen ve yapılandırılan verileri JDBC (Java Database 
Connectivity) köprüsü aracılığıyla yerel PostgreSQL veritabanına aktarır. İşlem sırasında 
loglama yaparak sürecin izlenebilirliğini sağlar ve veritabanı tablolarını 
belirlenen modda günceller.

====================================================================================================
"""

import logging
from pyspark.sql import DataFrame
from typing import Dict, Any

# Loglama yapılandırması: Sürecin tarihsel takibi için etl_process.log dosyası oluşturulur.
logging.basicConfig(
    filename="etl_process.log",
    level=logging.INFO,
    format="%(asctime)s - %(message)s"
)

def load_to_postgres(df, table_name, db_config):
    """
    PySpark DataFrame'i PostgreSQL veritabanına JDBC sürücüsü kullanarak yazar.
    """
    # Veritabanı bağlantı adresi (URL) oluşturulur.
    url = f"jdbc:postgresql://{db_config['host']}:{db_config['port']}/{db_config['dbname']}"

    try:
        # Yükleme öncesi veri miktarı doğrulanır.
        row_count = df.count()
        print(f"\n [{table_name}] Tablosu Yükleniyor... (Satır Sayısı: {row_count})")
        
        # PySpark JDBC Write API kullanımı:
        # .mode("overwrite"): Tablo varsa üzerine yazar, yoksa oluşturur.
        df.write.format("jdbc").options(
            url=url,
            dbtable=table_name,
            user=db_config["user"],
            password=db_config["password"],
            driver="org.postgresql.Driver"
        ).mode("overwrite").save()

        # Başarı geri bildirimi
        print(f" BAŞARILI: '{table_name}' PostgreSQL veritabanına kaydedildi.")
        logging.info(f"{table_name} loaded successfully ({row_count} rows)")

    except Exception as e:
        # Hata durumunda detaylı hata mesajı ve log kaydı.
        print(f" HATA: '{table_name}' yüklenirken bir sorun oluştu!")
        print(f"Hata Detayı: {e}")
        logging.error(f"Load error {table_name}: {e}")