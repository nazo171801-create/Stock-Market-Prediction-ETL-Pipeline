"""
====================================================================================================
PROJE ADI: Uçtan Uca Hisse Senedi Analitik ve Tahmin Projesi (2025-2026 Term Homework)
MODÜL: scoring.py (Tahmin ve Kayıt Katmanı)

BU KODDA NE YAPILIYOR?
Bu modül, projenin "çıktı" merkezidir. Daha önce eğitilip kaydedilen (pickle) modelleri yükler, 
PostgreSQL'den güncel verileri çeker, modelin ihtiyaç duyduğu teknik göstergeleri (RSI, SMA vb.) 
hesaplar ve 2024 sonrası "Prediction Period" için al/sat sinyalleri üretir. Üretilen bu 
tahmin skorları, nihai performans ölçümü için veritabanındaki 'stock_scores' tablosuna yazılır.

====================================================================================================
"""

import pickle
import pandas as pd
import psycopg2
from psycopg2.extras import execute_values

# Veritabanı bağlantı konfigürasyonu 
DB = {
    "host":"localhost",
    "port":"5432",
    "user":"postgres",
    "password":"naz1718",
    "database":"term_homework"
}

def read_db(q):
    """PostgreSQL veritabanından veri okumak için yardımcı fonksiyon."""
    conn = psycopg2.connect(**DB)
    df = pd.read_sql(q, conn)
    conn.close()
    return df

def calculate_features(df, market):
    """
    Öznitelik Mühendisliği (Feature Engineering):
    Modelleme aşamasında kullanılan teknik göstergeleri ham veriden türetir.
    """
    df = pd.merge(df, market, on="date", how="left")
    
    # Modelin beklediği sütun isimlerine (Case-Sensitive) uyum sağlama
    df = df.rename(columns={"close": "Close", "market_close": "Index_Close"})
    
    # RSI - Aşırı alım/satım bölgelerini belirler.
    df["RSI"] = 100 - (100 / (1 + (
        df["Close"].diff().clip(lower=0).rolling(14).mean() /
        df["Close"].diff().clip(upper=0).abs().rolling(14).mean()
    )))
    # SMA - Trend takibi sağlar.
    df["SMA_10"] = df["Close"].rolling(10).mean()
    df["SMA_50"] = df["Close"].rolling(50).mean()
    # Günlük Yüzdesel Değişim
    df["Price_Chg"] = df["Close"].pct_change()
    
    return df.dropna()

if __name__=="__main__":
    print(" Prediction Pipeline Başladı (Harf Uyumu Düzeltildi)")

    # S&P 500 (^GSPC) verisini çekme 
    market = read_db("""
        SELECT "Date" AS date, "Close" AS market_close
        FROM index_prices
        WHERE "Ticker"='^GSPC'
        ORDER BY date
    """)
    market["date"] = pd.to_datetime(market["date"])

    scores = []

    # Belirlenen hisseler üzerinde döngü (AAPL, NVDA, TSLA) 
    for t in ["AAPL", "NVDA", "TSLA"]:
        try:
            # 1. Kayıtlı Modeli Yükleme (Pickle) 
            model_path = f"models/model_{t}.pkl"
            with open(model_path, "rb") as f:
                model = pickle.load(f)
            
            # 2. Güncel Hisse Verisini Çekme
            stock = read_db(f"""
                SELECT "Ticker" AS ticker, "Date" AS date, "Close" AS close
                FROM stock_prices
                WHERE "Ticker"='{t}'
                ORDER BY date
            """)
            stock["date"] = pd.to_datetime(stock["date"])

            # 3. Özellikleri Hesaplama ve Tahmin Periyodunu Filtreleme 
            df = calculate_features(stock, market)
            df = df[df["date"] >= "2024-01-01"]

            # 4. Tahmin Üretme 
            X = df[["Close", "Index_Close", "SMA_10", "SMA_50", "RSI", "Price_Chg"]]
            
            # Strateji: Olasılık eşik değeriyle (threshold) al sinyali oluşturma
            threshold = 0.30 if t == "NVDA" else 0.40
            prob = model.predict_proba(X)[:, 1]
            df["score"] = (prob > threshold).astype(int) # 1: Buy, 0: Hold/Sell 

            res = df[["ticker", "date", "Close", "score"]].rename(columns={"Close": "close"})
            scores.append(res)
            print(f" {t} için tahminler üretildi.")
            
        except Exception as e:
            print(f" {t} işlenirken hata oluştu: {e}")

    # 5. Sonuçları PostgreSQL'e Yazma 
    if scores:
        final = pd.concat(scores)
        conn = psycopg2.connect(**DB)
        cur = conn.cursor()
        cur.execute("DROP TABLE IF EXISTS stock_scores")
        cur.execute("""
            CREATE TABLE stock_scores(
                ticker TEXT,
                date DATE,
                close DOUBLE PRECISION,
                score INT
            )
        """)
        execute_values(
            cur,
            "INSERT INTO stock_scores (ticker, date, close, score) VALUES %s",
            [tuple(x) for x in final.to_numpy()]
        )
        conn.commit()
        conn.close()
        print("\n Tahminler başarıyla PostgreSQL'e yazıldı!")