# TERM_HOMEWORK/data_loading/main.py

"""
====================================================================================================
PROJE ADI: Uçtan Uca Hisse Senedi Analitik ve Tahmin Projesi (2025-2026 Term Homework)
MODÜL: main.py (ETL Orkestrasyonu)

BU KODDA NE YAPILIYOR?
Bu modül, projenin "Veri Toplama ve İşleme" (ETL) aşamasını yöneten ana merkezdir. 
Yahoo Finance API üzerinden ham verileri (Hisseler, Endeksler, Makro Veriler ve Finansallar) 
çeker, PySpark kullanarak bu verileri temizler ve yapılandırır; son olarak ise 
modelleme aşamasında kullanılmak üzere PostgreSQL veritabanına kalıcı olarak kaydeder.

====================================================================================================
"""

from pyspark.sql import SparkSession
# extract, transformation ve load modülleri proje klasöründen içe aktarılıyor.
# Bu modüller sırasıyla, yfinance ile veri çekme, PySpark ile veriyi temizleyip dönüştürme ve PostgreSQL'e yükleme işlemlerini içerir.
from extract import STOCKS, INDICES, MACROS, extract_price_data, extract_financials
from transformation import transform_price_data, transform_financials
from load import load_to_postgres
import findspark

# Spark Yolu Ayarı: findspark, PySpark'ı bir Python ortamında kullanabilmek için Spark'ın kurulu olduğu dizini belirtir.
# Bu, PySpark'ın gerekli kütüphanelerini bulmasını sağlar.
findspark.init(spark_home=r"C:\spark\spark-3.5.7-bin-hadoop3")

def main():
    print("\n" + "="*50)
    print("ETL SÜRECİ BAŞLATILIYOR...")
    print("="*50)

    # 1. Spark Oturumunu Başlatma
    # PySpark ile büyük veri işlemlerini yapabilmek için bir SparkSession oluşturulur.
    # .appName: Spark uygulamasının adı.
    # .master("local[*]"): Spark'ı, makinenin tüm çekirdeklerini kullanarak yerel modda çalıştırmasını sağlar.
    spark = SparkSession.builder \
        .appName("Final_Academic_ETL") \
        .master("local[*]") \
        .getOrCreate()

    # PostgreSQL Veritabanı Bağlantı Parametreleri
    # Verilerin yükleneceği veritabanı bilgileri tanımlanmıştır.
    db_config = {
        "host": "localhost",
        "port": "5432",
        "user": "postgres",
        "password": "naz1718", 
        "dbname": "term_homework"
    }

    # --- Fiyat Verisi ETL Akışı (Hisse Senetleri, Endeksler ve Makro Veriler) ---
    
    # ADIM 1: Hisse Senedi Fiyatları İşleniyor
    # 1. Extract : Yahoo Finance API (yfinance) üzerinden hisse senedi fiyat verileri çekilir (STOCKS listesi).
    stock_raw = extract_price_data(STOCKS)
    # 2. Transform : Çekilen veriler PySpark DataFrame'e dönüştürülür, temizlenir (örneğin eksik değer/veri tipi düzenlemesi) ve gerekli formatlama yapılır.
    stock_clean = transform_price_data(spark, stock_raw)
    # 3. Load : İşlenmiş veri, PostgreSQL veritabanındaki "stock_prices" tablosuna yüklenir.
    load_to_postgres(stock_clean, "stock_prices", db_config)

    print("\n ADIM 2: Endeks Verileri İşleniyor...")
    # Aynı süreç Endeks verileri için tekrarlanır ve "index_prices" tablosuna yüklenir.
    index_raw = extract_price_data(INDICES)
    index_clean = transform_price_data(spark, index_raw)
    load_to_postgres(index_clean, "index_prices", db_config)

    print("\n ADIM 3: Makro Ekonomik Veriler İşleniyor...")
    # Aynı süreç Makroekonomik veriler (altın, petrol, DXY vb.) için tekrarlanır ve "macro_prices" tablosuna yüklenir.
    macro_raw = extract_price_data(list(MACROS.values()))
    macro_clean = transform_price_data(spark, macro_raw)
    load_to_postgres(macro_clean, "macro_prices", db_config)

    # --- Finansal Tablo Verileri ETL Akışı ---
    
    print("\n ADIM 4: Finansal Tablolar İşleniyor...")
    # 1. Extract : Hisse senetleri için Analist önerileri, Piyasa Değeri, Finansal Tablolar (Gelir Tablosu, Bilanço, Nakit Akış) gibi ek bilgiler çekilir.
    fin_raw = extract_financials(STOCKS)
    # 2. Transform : Finansal veriler PySpark ile analiz ve modellemeye uygun, normalize bir formata dönüştürülür.
    fin_clean = transform_financials(spark, fin_raw)
    # 3. Load : İşlenmiş finansal metrikler, "financial_metrics" tablosuna yüklenir.
    load_to_postgres(fin_clean, "financial_metrics", db_config)

    # --- Süreç Sonu ---
    print("\n" + "="*50)
    print(" TEBRİKLER! TÜM ETL SÜRECİ TAMAMLANDI.")
    print(" Veriler 'term_homework' veritabanına başarıyla aktarıldı.")
    print("="*50)

    # İşlem tamamlandıktan sonra Spark oturumu kapatılır.
    spark.stop()

if __name__ == "__main__":
    main()